<template>
    <div class="container">
      <div class="wrap">
        <form @submit.prevent="handleSubmit">
          <table>
            <tr>
              <td>
                <input
                  class="form-input"
                  type="text"
                  id="mobile"
                  v-model="mobile"
                  placeholder="请输入手机号"
                  required
                />
              </td>
            </tr>
            <tr>
              <td>
                <input
                  class="form-input"
                  type="password"
                  id="password"
                  v-model="password"
                  placeholder="请输入密码"
                  required
                />
              </td>
            </tr>
          </table>
          <div class="form-action">
            <input class="form-btn" type="submit" value="登录" />
          </div>
          <div class="register-link">
            <router-link to="/register">还没有账号，去注册</router-link>
          </div>
        </form>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    name: "Login",
    data() {
      return {
        mobile: "",
        password: "",
      };
    },
    methods: {
      handleSubmit() {
        if (!this.mobile || !this.password) {
          alert("请填写所有字段！");
          return;
        }
  
        const data = {
          mobile: this.mobile,
          password: this.password,
        };
  
        console.log(data);
        // Add your form submission logic here, such as making an API request
      },
    },
  };
  </script>
  
  <style lang="scss" scoped>
  .container {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    background-color: #f0f0f0; /* Optional background color for the page */
  }
  
  .wrap {
    width: 90%;
    max-width: 300px;
    background-color: rgba(255, 255, 255, 0.8); /* Semi-transparent background */
    border: 1px solid #a3a3a3;
    border-radius: 10px; /* Rectangular shape with subtle rounding */
    padding: 65px 25px;
    font-size: 15px;
    text-align: center;
    box-shadow: 20px 10px 9px rgba(0, 0, 0, 0.1); /* Subtle shadow for depth */
    backdrop-filter: blur(8px); /* Optional: adds a blur effect behind the form */
  }
  
  .form-input {
    width: 130%;
    height: 35px;
    margin: 10px 0;
    padding-left: 15px;
    border-radius: 5px; /* Rectangular input shape */
    font-size: 16px;
    border: 2px solid #ddd;
    background-color: #f7f7f7;
  }
  
  .form-btn {
    margin: 15px 0;
    background-color: #6c63ff; /* New primary color */
    height: 40px;
    width: 40%;
    font-size: 18px;
    border-radius: 5px; /* Rectangular button shape */
    cursor: pointer;
    border: none;
    color: white;
    transition: background-color 0.3s ease;
  }
  
  .form-btn:hover {
    background-color: #5752d1; /* Slightly darker hover effect */
  }
  
  .form-action {
    margin-bottom: 15px;
  }
  
  .register-link {
    margin-top: 20px;
    text-align: center;
  }
  
  @media (max-width: 600px) {
    .wrap {
      margin-top: 100px;
    }
  }
  </style>
  