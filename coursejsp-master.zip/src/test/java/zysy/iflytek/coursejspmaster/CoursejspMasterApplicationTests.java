package zysy.iflytek.coursejspmaster;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoursejspMasterApplicationTests {

    @Test
    void contextLoads() {
    }

}
