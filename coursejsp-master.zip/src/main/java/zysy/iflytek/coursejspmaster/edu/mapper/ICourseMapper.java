package zysy.iflytek.coursejspmaster.edu.mapper;

import zysy.iflytek.coursejspmaster.edu.entity.Course;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import zysy.iflytek.coursejspmaster.edu.vo.CourseVO;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author YinDehua
 * @since 2024-06-18
 */
public interface ICourseMapper extends BaseMapper<Course> {
    List<CourseVO> listVO();
}
