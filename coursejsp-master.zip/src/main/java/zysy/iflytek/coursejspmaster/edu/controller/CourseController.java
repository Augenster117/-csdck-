package zysy.iflytek.coursejspmaster.edu.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;
import zysy.iflytek.coursejspmaster.edu.entity.Course;
import zysy.iflytek.coursejspmaster.edu.entity.CourseStudyhistory;
import zysy.iflytek.coursejspmaster.edu.service.ICourseService;
import zysy.iflytek.coursejspmaster.edu.service.ICourseStudyhistoryService;
import zysy.iflytek.coursejspmaster.edu.vo.CourseVO;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Date;
import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author YinDehua
 * @since 2024-06-18
 */
//@RestController
@Controller
@RequestMapping("/edu/course")
public class CourseController {
    @Autowired
    private ICourseService courseService;

    @GetMapping("/detail")
    public String detail(Integer id, HttpServletRequest req) {
        Course course = courseService.getById(id);
        req.setAttribute("course", course);
        return "forward:/courseupdate.jsp";
    }

    @GetMapping("/list")
    public String list(HttpServletRequest req) {
//        List<Course> list = courseService.list();
//        req.setAttribute("courselist", list);
        List<CourseVO> listVO = courseService.listVO();
        req.setAttribute("courselist", listVO);
        return "forward:/courselist.jsp";
    }

    @PostMapping("/add")
    public String add(Course course) throws UnsupportedEncodingException {
        course.setCreateTime(new Date());
        course.setUpdateTime(new Date());
        boolean bSuccess = courseService.save(course);
        if (bSuccess) {
            return "redirect:/edu/course/list";
        } else {
            String message = "添加课程失败";
            return "redirect:/courseadd.jsp?message=" + URLEncoder.encode(message, "UTF-8");
        }
    }

    @PostMapping("/update")
    public String update(Course course) throws UnsupportedEncodingException {
        course.setUpdateTime(new Date());
        boolean bSuccess = courseService.updateById(course);
        if (bSuccess) {
            return "redirect:/edu/course/list";
        } else {
            String message = "修改课程失败";
            return "redirect:/courseupdate.jsp?message=" + URLEncoder.encode(message, "UTF-8");
        }
    }

    @GetMapping("/remove")
    public String remove(Integer id) {
        courseService.removeById(id);
        return "redirect:/edu/course/list";
    }

}

