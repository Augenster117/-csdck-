package zysy.iflytek.coursejspmaster.edu.mapper;

import zysy.iflytek.coursejspmaster.edu.entity.CourseStudyhistory;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import zysy.iflytek.coursejspmaster.edu.vo.CourseStudyhistoryVO;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author YinDehua
 * @since 2024-06-18
 */
public interface ICourseStudyhistoryMapper extends BaseMapper<CourseStudyhistory> {

    List<CourseStudyhistoryVO> listByStudent(Integer studentId);
}
