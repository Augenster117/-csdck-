package zysy.iflytek.coursejspmaster.edu.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import zysy.iflytek.coursejspmaster.edu.entity.Course;

@Data
public class CourseVO extends Course {
    @ApiModelProperty("教职工号")
    private String teacherWorkNo;

    @ApiModelProperty("教师姓名")
    private String teacherName;
}
