package zysy.iflytek.coursejspmaster.edu.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;
import zysy.iflytek.coursejspmaster.edu.entity.CourseStudyhistory;
import zysy.iflytek.coursejspmaster.edu.service.ICourseStudyhistoryService;
import zysy.iflytek.coursejspmaster.edu.vo.CourseStudyhistoryVO;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author YinDehua
 * @since 2024-06-18
 */
@Controller
//@RestController
@RequestMapping("/edu/courseStudyhistory")
public class CourseStudyhistoryController {
    @Autowired
    private ICourseStudyhistoryService studyhistoryService;

    @GetMapping("/list")
    public String list(Integer studentId, HttpServletRequest request) {
        List<CourseStudyhistoryVO> hisVOList = studyhistoryService.listByStudent(studentId);
        request.setAttribute("courseStudyList", hisVOList);

        return "forward:/courseStudyList1.jsp";
    }

    @PostMapping("/add")
    public String add(CourseStudyhistory crsHis) {
        crsHis.setCreateTime(new Date());
        crsHis.setUpdateTime(new Date());
        boolean bSuccess = studyhistoryService.save(crsHis);
        return "redirect:/edu/courseStudyhistory/list?studentId=" + crsHis.getStudentId();
    }

    @GetMapping("/remove")
    public String remove(Integer id, Integer studentId) {
        boolean bRemove = studyhistoryService.removeById(id);
        return "redirect:/edu/courseStudyhistory/list?studentId=" + studentId; //跳转到课程列表
    }
}

