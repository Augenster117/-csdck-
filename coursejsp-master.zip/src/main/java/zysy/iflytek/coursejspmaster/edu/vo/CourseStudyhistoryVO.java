package zysy.iflytek.coursejspmaster.edu.vo;

import lombok.Data;
import zysy.iflytek.coursejspmaster.edu.entity.CourseStudyhistory;

@Data
public class CourseStudyhistoryVO extends CourseStudyhistory {
    private String studentName;
    private String courseCno;
    private String courseName;
    private String teacherWorkNo;
    private String teacherName;
}
