package zysy.iflytek.coursejspmaster.edu.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import zysy.iflytek.coursejspmaster.edu.entity.Course;
import zysy.iflytek.coursejspmaster.edu.mapper.ICourseMapper;
import zysy.iflytek.coursejspmaster.edu.service.ICourseService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import zysy.iflytek.coursejspmaster.edu.vo.CourseVO;

import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author YinDehua
 * @since 2024-06-18
 */
@Service
public class CourseServiceImpl extends ServiceImpl<ICourseMapper, Course> implements ICourseService {
    @Autowired
    private ICourseMapper courseMapper;

    @Override
    public List<CourseVO> listVO() {
        return courseMapper.listVO();
    }
}
