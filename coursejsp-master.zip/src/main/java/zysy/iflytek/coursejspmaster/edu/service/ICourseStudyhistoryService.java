package zysy.iflytek.coursejspmaster.edu.service;

import zysy.iflytek.coursejspmaster.edu.entity.CourseStudyhistory;
import com.baomidou.mybatisplus.extension.service.IService;
import zysy.iflytek.coursejspmaster.edu.vo.CourseStudyhistoryVO;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author YinDehua
 * @since 2024-06-18
 */
public interface ICourseStudyhistoryService extends IService<CourseStudyhistory> {

    public void add(CourseStudyhistory his);

    public List<CourseStudyhistoryVO> listByStudent(Integer studentId);
}
