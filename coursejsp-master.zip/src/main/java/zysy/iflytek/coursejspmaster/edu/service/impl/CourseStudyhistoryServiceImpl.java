package zysy.iflytek.coursejspmaster.edu.service.impl;

import zysy.iflytek.coursejspmaster.edu.entity.CourseStudyhistory;
import zysy.iflytek.coursejspmaster.edu.mapper.ICourseStudyhistoryMapper;
import zysy.iflytek.coursejspmaster.edu.service.ICourseStudyhistoryService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import zysy.iflytek.coursejspmaster.edu.vo.CourseStudyhistoryVO;

import java.util.Date;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author YinDehua
 * @since 2024-06-18
 */
@Service
public class CourseStudyhistoryServiceImpl extends ServiceImpl<ICourseStudyhistoryMapper, CourseStudyhistory> implements ICourseStudyhistoryService {

    @Override
    public void add(CourseStudyhistory his) {
        his.setCreateTime(new Date());
        his.setUpdateTime(new Date());
        his.setCourseStatus(1);
        baseMapper.insert(his);
    }

    @Override
    public List<CourseStudyhistoryVO> listByStudent(Integer studentId) {
        return baseMapper.listByStudent(studentId);
    }
}
