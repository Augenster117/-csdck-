package zysy.iflytek.coursejspmaster.ums.service;

import zysy.iflytek.coursejspmaster.ums.entity.Student;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author YinDehua
 * @since 2024-06-18
 */
public interface IStudentService extends IService<Student> {

    Student login(String mobile);

    Boolean isMobileExist(String mobile);
}
