package zysy.iflytek.coursejspmaster.ums.mapper;

import org.apache.ibatis.annotations.Param;
import zysy.iflytek.coursejspmaster.ums.entity.Student;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author YinDehua
 * @since 2024-06-18
 */
public interface IStudentMapper extends BaseMapper<Student> {

    List<Student> testxml();

    Integer testdel(@Param("ids") List<Integer> ids);
}
