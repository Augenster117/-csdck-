package zysy.iflytek.coursejspmaster.ums.controller;

import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import zysy.iflytek.coursejspmaster.common.util.VerifyCodeUtils;
import zysy.iflytek.coursejspmaster.ums.entity.Student;
import zysy.iflytek.coursejspmaster.ums.service.IStudentService;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Objects;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author YinDehua
 * @since 2024-06-18
 */
//@RestController
@Controller
@RequestMapping("/ums/student")
@Api(tags = "学生模块控制器")
public class StudentController {
    @Autowired
    private IStudentService studentService;

    @PostMapping("/login")
    public String login(Student student, HttpSession session) throws UnsupportedEncodingException {
        // 1.从数据库获取登录用户
        Student stuTmp = studentService.login(student.getMobile());
        // 2.1.如果数据库不存在改用户，提示“用户不存在”
        if (Objects.isNull(stuTmp)) {
            String message = "该用户不存在";
            return "redirect:/login.jsp?message=" + URLEncoder.encode(message, "UTF-8");
        }
        // 2.2 如果存在该用户，比较密码
        // 3.1 密码错误，提示
        if (student.getPassword().isEmpty()
                || !student.getPassword().equals(stuTmp.getPassword())) {
            String message = "用户密码错误";
            return "redirect:/login.jsp?message=" + URLEncoder.encode(message, "UTF-8");
        }

        stuTmp.setPassword("");
        session.setAttribute("student", stuTmp);

        // 3.2 密码正确，登录成功，跳转至list页面
        return "redirect:/edu/course/list";
    }

    @PostMapping("/regist")
    public String regist(Student student, String verifycode, HttpSession session) throws UnsupportedEncodingException {
        // 1.验证码校验
        Object codeTmp = session.getAttribute("verifycode");
        if (Objects.isNull(verifycode) || !verifycode.equals(codeTmp)) {
            String message = "验证码错误，请重试！";
            return "redirect:/regist.jsp?message=" + URLEncoder.encode(message, "UTF-8");
        }
        // 2.检查手机号是否已注册
        Boolean bExist = studentService.isMobileExist(student.getMobile());
        if (bExist) {
            String message = "该手机号已注册，请修改后重试！";
            return "redirect:/regist.jsp?message=" + URLEncoder.encode(message, "UTF-8");
        }
        // 3.存储student到数据库
        boolean bSucess = studentService.save(student);
        String message = (bSucess) ? "注册成功！" : "注册失败，请稍后重试！";
        return "redirect:/regist.jsp?message=" + URLEncoder.encode(message, "UTF-8");
    }

    @GetMapping("/verifycode")
    public void verifycode(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        // 1.生成随机字符串
        String verifycode = VerifyCodeUtils.generateVerifyCode(4);
        System.out.println(verifycode);
        // 2.保存随机字符串到session
        HttpSession session = req.getSession();
        session.setAttribute("verifycode", verifycode);
        // 3.将随机数字符串生成图片
        // 4.通过response响应图片
        resp.setContentType("image/png"); //指定响应类型为图片
        ServletOutputStream outputStream = resp.getOutputStream();
        VerifyCodeUtils.outputImage(220, 60, outputStream, verifycode);
    }

}

