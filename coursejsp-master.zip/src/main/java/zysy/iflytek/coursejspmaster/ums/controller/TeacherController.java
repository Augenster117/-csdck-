package zysy.iflytek.coursejspmaster.ums.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import zysy.iflytek.coursejspmaster.ums.entity.Teacher;
import zysy.iflytek.coursejspmaster.ums.service.ITeacherService;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author YinDehua
 * @since 2024-06-18
 */
@RestController
@RequestMapping("/ums/teacher")
public class TeacherController {
    @Autowired
    private ITeacherService teacherService;

    @GetMapping("/detail")
    public Teacher detail(Integer id) {
        return teacherService.getById(id);
    }

    @GetMapping("/list")
    public List<Teacher> list() {
        return teacherService.list();
    }

    @PostMapping("/add")
    public String add(@RequestBody Teacher teacher) {
        boolean bSuccess = teacherService.save(teacher);
        if (bSuccess) {
            return "添加教师成功";
        } else {
            return "添加教师失败";
        }
    }

    @PostMapping("/update")
    public String update(@RequestBody Teacher teacher) {
        boolean bSuccess = teacherService.updateById(teacher);
        if (bSuccess) {
            return "修改教师成功";
        } else {
            return "修改教师失败";
        }
    }

    @PostMapping("/remove")
    public String remove(@RequestParam List<Integer> ids) {
        boolean bSuccess = teacherService.removeByIds(ids);
        if (bSuccess) {
            return "删除教师成功";
        } else {
            return "删除教师失败";
        }
    }




}

