package zysy.iflytek.coursejspmaster.ums.service.impl;

import zysy.iflytek.coursejspmaster.ums.entity.Teacher;
import zysy.iflytek.coursejspmaster.ums.mapper.ITeacherMapper;
import zysy.iflytek.coursejspmaster.ums.service.ITeacherService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author YinDehua
 * @since 2024-06-18
 */
@Service
public class TeacherServiceImpl extends ServiceImpl<ITeacherMapper, Teacher> implements ITeacherService {

}
