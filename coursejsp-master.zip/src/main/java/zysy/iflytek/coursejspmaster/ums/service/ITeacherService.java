package zysy.iflytek.coursejspmaster.ums.service;

import zysy.iflytek.coursejspmaster.ums.entity.Teacher;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author YinDehua
 * @since 2024-06-18
 */
public interface ITeacherService extends IService<Teacher> {

}
