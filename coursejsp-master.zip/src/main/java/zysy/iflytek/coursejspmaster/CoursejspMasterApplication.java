package zysy.iflytek.coursejspmaster;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("zysy.iflytek.coursejspmaster.**.mapper")
public class CoursejspMasterApplication {

    public static void main(String[] args) {
        SpringApplication.run(CoursejspMasterApplication.class, args);
    }

}
