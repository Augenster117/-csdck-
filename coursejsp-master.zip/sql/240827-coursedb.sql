-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: coursedb
-- ------------------------------------------------------
-- Server version	5.7.30-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `edu_course`
--

DROP TABLE IF EXISTS `edu_course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `edu_course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_cno` varchar(11) DEFAULT NULL COMMENT '课程号',
  `course_name` varchar(50) DEFAULT '' COMMENT '课程名称',
  `teacher_id` int(11) DEFAULT '0' COMMENT '教师id',
  `is_valid` tinyint(1) DEFAULT '1' COMMENT '课程有效性（1-上架，2-下架）',
  `is_deleted` tinyint(1) DEFAULT '0' COMMENT '是否已删除 0-未删除 1-已删除',
  `sort` tinyint(2) DEFAULT '0' COMMENT '排序',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edu_course`
--

LOCK TABLES `edu_course` WRITE;
/*!40000 ALTER TABLE `edu_course` DISABLE KEYS */;
INSERT INTO `edu_course` VALUES (1,'WL230001','物理23学年',3,1,0,1,'2023-03-06 01:25:52','2024-03-01 10:11:31'),(2,'HX230002','化学23学年',6,1,0,1,'2023-03-06 01:26:29','2023-12-20 00:03:49');
/*!40000 ALTER TABLE `edu_course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edu_course_studyhistory`
--

DROP TABLE IF EXISTS `edu_course_studyhistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `edu_course_studyhistory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) DEFAULT '0' COMMENT '课程id',
  `student_id` int(11) DEFAULT '0' COMMENT '学生id',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `course_status` int(2) DEFAULT '0' COMMENT '课程状态（0-可申请，1-待审核，2-已审核）',
  `sort` int(2) DEFAULT '0' COMMENT '排序',
  `is_deleted` tinyint(1) DEFAULT '0' COMMENT '是否已删除 0-未删除 1-已删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edu_course_studyhistory`
--

LOCK TABLES `edu_course_studyhistory` WRITE;
/*!40000 ALTER TABLE `edu_course_studyhistory` DISABLE KEYS */;
INSERT INTO `edu_course_studyhistory` VALUES (19,1,8,'2023-06-16 10:57:37','2023-06-16 10:57:37',1,0,0),(32,2,5,'2023-08-01 21:44:39','2023-08-01 21:44:39',0,0,0),(50,2,27,'2024-06-23 23:30:31','2024-06-23 23:30:31',1,0,0),(55,1,27,NULL,NULL,0,0,0),(56,1,27,NULL,NULL,0,0,0),(57,2,27,NULL,NULL,0,0,0),(58,1,27,NULL,NULL,0,0,0),(59,2,27,NULL,NULL,0,0,0),(60,1,27,'2024-06-27 14:38:22','2024-06-27 14:38:22',0,0,0),(62,1,5,'2024-08-25 23:48:24','2024-08-25 23:48:24',0,0,0);
/*!40000 ALTER TABLE `edu_course_studyhistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ums_student`
--

DROP TABLE IF EXISTS `ums_student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ums_student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mobile` varchar(11) DEFAULT NULL COMMENT '手机号',
  `password` varchar(50) DEFAULT NULL COMMENT '密码',
  `name` varchar(255) DEFAULT NULL COMMENT '用户名',
  `gender` tinyint(1) DEFAULT '1' COMMENT '性别  1男  2女',
  `age` tinyint(3) DEFAULT '0' COMMENT '年龄',
  `create_time` datetime DEFAULT NULL COMMENT '注册时间',
  `update_time` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `is_deleted` tinyint(1) DEFAULT '0' COMMENT '是否已删除 0-未删除 1-已删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ums_student`
--

LOCK TABLES `ums_student` WRITE;
/*!40000 ALTER TABLE `ums_student` DISABLE KEYS */;
INSERT INTO `ums_student` VALUES (5,'13618504364','123','张三',1,20,'2023-09-09 18:02:56','2023-12-18 23:45:37',0),(27,'123','123','123',2,20,NULL,NULL,0);
/*!40000 ALTER TABLE `ums_student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ums_teacher`
--

DROP TABLE IF EXISTS `ums_teacher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ums_teacher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `work_no` varchar(20) DEFAULT '' COMMENT '教职工号',
  `name` varchar(200) DEFAULT '' COMMENT '教师姓名',
  `gender` tinyint(1) DEFAULT '1' COMMENT '性别  1男  2女',
  `mobile` varchar(11) DEFAULT NULL COMMENT '手机号',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `is_deleted` tinyint(1) DEFAULT '0' COMMENT '是否已删除 0-未删除 1-已删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ums_teacher`
--

LOCK TABLES `ums_teacher` WRITE;
/*!40000 ALTER TABLE `ums_teacher` DISABLE KEYS */;
INSERT INTO `ums_teacher` VALUES (3,'ZY0001','admin',2,'13600000002','2023-09-30 18:45:39','2023-10-07 18:45:42',0),(6,'ZY0002','张老师',1,'13600000002','2023-10-04 08:46:31','2023-10-05 08:46:33',0),(7,'ZY0003','李老师',1,'13600000002','2023-10-04 08:46:31','2023-10-05 08:46:33',0),(8,'ZY0004','王老师',1,'13600000002','2023-10-04 08:46:31','2023-10-05 08:46:33',0),(9,'1','2',1,'3','2024-06-04 08:46:31','2024-06-05 08:46:33',0),(10,'ZY00021111','张老师1111',1,'13600000002','2024-10-04 08:46:31','2024-10-05 08:46:33',0);
/*!40000 ALTER TABLE `ums_teacher` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-27 10:49:19
